<?php
// cadastro.php
require 'conexao.php';


header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
// TESTE: resposta simples
echo json_encode(["status" => "ok"]);


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true); 

    
    if (
        !isset($input['email'], $input['senha'], $input['nm_usuario'], $input['cpf'], 
               $input['dt_nascimento'], $input['telefone'], $input['rua'], $input['cep'])
    ) {

         echo json_encode(['sucesso' => false, 'erro' => 'Dados de cadastro incompletos.']);
         exit;
    }
    
    $senha_hash = password_hash($input['senha'], PASSWORD_DEFAULT); // Cria o hash seguro da senha.

    try {
        $pdo->beginTransaction(); // Inicia a transação.

        // --- 3. INSERT na tabela 'usuario' ---
        $sql_usuario = "INSERT INTO usuario (nm_usuario, cpf, dt_nascimento, telefone, email, senha, foto, tipo) 
                        VALUES (?, ?, ?, ?, ?, ?, ?, 'user')"; // Define 'user' como tipo padrão.
        $query = $pdo->prepare($sql_usuario);
        $query->execute([
            $input['nm_usuario'], $input['cpf'], $input['dt_nascimento'], 
            $input['telefone'], $input['email'], $senha_hash, $input['foto'] ?? null 
        ]);

        $id_usuario = $pdo->lastInsertId(); // Pega o ID gerado para o novo usuário.

        $pdo->commit(); // 5. Finaliza a transação, salvando ambas as inserções.
        echo json_encode(['sucesso' => true, 'mensagem' => 'Cadastro realizado com sucesso!', 'id_usuario' => $id_usuario]);

    } catch (\PDOException $e) {
        $pdo->rollBack();//tratamento de erro para dados duplcados
        
     
        echo json_encode(['sucesso' => false, 'erro' => 'Erro no cadastro: E-mail ou CPF já registrados.']);
    }
}
?>