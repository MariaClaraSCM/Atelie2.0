<?php
// conexao.php

$host='localhost';
$banco='db_atelie'; // Confirme que este banco existe
$usuario='root';    // Usuário padrão do XAMPP/WAMP
$senha='';          // Senha padrão do XAMPP/WAMP (geralmente vazia)

try {
    $pdo=new PDO("mysql:host=$host;dbname=$banco", $usuario, $senha);
} catch(PDOException $e){
    // Se a conexão falhar aqui, você verá o erro no lado do PHP.
    die("erro na conexão: ". $e->getMessage()); 
}
?>